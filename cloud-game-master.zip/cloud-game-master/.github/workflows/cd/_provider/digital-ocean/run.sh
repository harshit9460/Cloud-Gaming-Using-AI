#!/bin/bash

ufw disable 2> /dev/null;
source /etc/profile;
